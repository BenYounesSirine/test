import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ex4coloriage',
  templateUrl: './ex4coloriage.component.html',
  styleUrls: ['./ex4coloriage.component.css']
})
export class Ex4coloriageComponent implements OnInit {

  couleur="";
  familly="";
  police=["Arial","Calibri","Times New Roman"];
  theme="ete";
  

  
  constructor() { }

  ngOnInit() {
  }

}
